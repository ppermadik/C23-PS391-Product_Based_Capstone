package com.dicoding.submission.capstone.data.datakota

data class Kota(
    val id: String,
    val name: String,
    var photo: Int,

    )
