package com.dicoding.submission.capstone.data.datakota

import com.dicoding.submission.capstone.R

object Data {
    val kota: List<Kota> = listOf(
        Kota(
            "1",
            "Surabaya Kota",
            R.drawable.w,
        ),
        Kota(
            "2",
            "Malang Kota",
            R.drawable.w,

        ),
        Kota(
            "3",
            "Bayuwangi Kabupaten",
            R.drawable.w,

        ),
        Kota(
            "4",
            "Blitar Kbupaten",
            R.drawable.w,

        ),
        Kota(
            "5",
            "Jombang Kab",
            R.drawable.w,

        ),
        Kota(
            "6",
            "Madiun Kab",
            R.drawable.w,

        ),
        Kota(
            "7",
            "mojokertokab",
            R.drawable.w,
        ),
        Kota(
            "8",
            "nganjukkab",
            R.drawable.w,
        ),
        Kota(
            "9",
            "pasuruankab",
            R.drawable.w,
        ),
        Kota(
            "10",
            "sidoarjokab",
            R.drawable.w,
        ),
        Kota(
            "11",
            "situbondokab",
            R.drawable.w,
        ),
        Kota(
            "12",
            "madiunkota",
            R.drawable.w,
        ),

    )
}